#' Load a YAML file to the global environment
#'
#' @param file_path Path to a YAML file
#' @param pos Numeric environment to assign to, defaults to 1 (.GlobalEnv)
#'
#' @export
#'
#' @importFrom yaml read_yaml
load_yaml <- function(file_path, pos = 1){
  
  input <- suppressWarnings(yaml::read_yaml(file_path))
  
  for (idx in 1:length(input)){
    assign(names(input[idx]), input[[idx]], envir = as.environment(pos))
  }
  
  print("YAML loaded")
  
}