#' Extract file name from a file path
#'
#' @param file_path A file path
#'
#' @return The file name
#'
#' @import stringr
#'
get_file_from_filepath <- function(file_path){
  # extract everything after the last slash, then remove any remaining slashes and everything following the last period
  return(stringr::str_remove(stringr::str_extract(file_path, "/(?!.*/).+$"), "/|(\\.(?!.*\\.).+$)"))
}
