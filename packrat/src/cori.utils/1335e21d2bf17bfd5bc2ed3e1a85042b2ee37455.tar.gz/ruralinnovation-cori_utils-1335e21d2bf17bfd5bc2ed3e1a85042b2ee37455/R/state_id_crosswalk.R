#' Crosswalk of 3 common state identification formats
#'
#'A data set with full state name, state abbreviation, and state fips code
#'
#' @format A data frame with 55 rows and 3 variables:
"state_id_crosswalk"
