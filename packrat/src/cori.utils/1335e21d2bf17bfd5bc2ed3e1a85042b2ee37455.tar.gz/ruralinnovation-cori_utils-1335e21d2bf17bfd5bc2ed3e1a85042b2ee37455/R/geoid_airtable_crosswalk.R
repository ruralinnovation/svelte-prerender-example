#' Crosswalk of county geoid and Airtable ID ("NAMELSAD [STATE_ABBR]")
#'
#'A data set with county geoid and Airtable formatted ID
#'
#' @format A data frame with 3142 rows and 2 variables:
"geoid_airtable_crosswalk"
