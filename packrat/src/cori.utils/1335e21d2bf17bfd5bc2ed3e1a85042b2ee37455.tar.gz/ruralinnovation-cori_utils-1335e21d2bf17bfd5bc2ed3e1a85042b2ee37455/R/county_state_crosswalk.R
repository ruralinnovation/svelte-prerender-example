#' List of US counties and associates states
#'
#' Originates from sch_layer.non_geo_attr_county_pg_v3, last updated April 2021
#'
#' @format A data frame with 3142 rows and 3 variables:
"county_state_crosswalk"
