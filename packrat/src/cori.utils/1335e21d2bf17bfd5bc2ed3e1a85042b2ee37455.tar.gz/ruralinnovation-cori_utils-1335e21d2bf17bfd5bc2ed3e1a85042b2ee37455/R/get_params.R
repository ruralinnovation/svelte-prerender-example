#' Get named parameter lists from a config file
#'
#' @param config_names Names of config lists
#' @param config_file File to read from. Defaults to params.yml, the default name of the param file used in CORI pipelines
#'
#' @return A concatenated list of parameters
#' @export
#'
#' @importFrom config get
get_params <- function(config_names, config_file = 'params.yml'){
  return(
    unlist(
      lapply(config_names, function(cfg){config::get(cfg, file = config_file)}),
      recursive = FALSE
      )
  )
}
