#' Check for duplicate combinations of values
#'
#' @param data_tbl A data.frame, tibble, or data.table
#' @param ... One or more unquoted column names
#'
#' @return Boolean TRUE if duplicates of the given key column(s) exist, FALSE otherwise
#' @export
#'
#' @import dplyr
#' @import sf
#'
has_duplicates <- function(data_tbl, ...){

  cols <- enexprs(...)

  if ("sf" %in% class(data_tbl)){

    num_dupes <- data_tbl %>%
      sf::st_drop_geometry() %>%
      group_by(!!!cols) %>%
      count() %>%
      filter(.data$n > 1) %>%
      nrow()

  } else {

    num_dupes <- data_tbl %>%
      group_by(!!!cols) %>%
      count() %>%
      filter(.data$n > 1) %>%
      nrow()

  }

  return(num_dupes > 0)

}
