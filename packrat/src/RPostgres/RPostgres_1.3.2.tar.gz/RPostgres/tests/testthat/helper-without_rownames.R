without_rownames <- function(df) {
  row.names(df) <- NULL
  df
}
