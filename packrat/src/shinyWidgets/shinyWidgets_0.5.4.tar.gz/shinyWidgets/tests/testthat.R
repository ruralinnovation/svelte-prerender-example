library(testthat)
library(shinyWidgets)

test_check("shinyWidgets")
