## Test environments

* local Windows 10 install, R 4.0.3
* ubuntu 16.04, Windows 10, macOS (on GitHub Actions), R 4.0.4
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 0 note


-------

Fixed problems reported by CRAN + new function and new features.
Thanks!

Victor
