## Test environments
* local OS Windows 10 install, R 3.6.1
* ubuntu 14.04 (on travis-ci), R 3.6.1
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 0 note

* Fix a bug when using with an other package (shinymanager) .
  Thanks! Victor

