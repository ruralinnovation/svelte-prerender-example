library(testthat)
library(shinylogs)

test_check("shinylogs")
