# shinylogs 0.1.8

* Timestamp is now recorded in microseconds (fix [#6](https://github.com/dreamRs/shinylogs/issues/6)).


# shinylogs 0.1.7

* Fix a bug when used with {shinymanager} (fix [#2](https://github.com/dreamRs/shinylogs/issues/2)).


# shinylogs 0.1.6

* `use_tracking` is now exported to load dependencies directly in UI, usefull for big applications.
* Ability to print logs recorded in the console.


# shinylogs 0.1.5

* First release : Track and record the use of applications and the user's interactions with 'Shiny' inputs. Allow to save inputs clicked, output generated and eventually errors.
