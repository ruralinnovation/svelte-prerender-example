---
name  : Bug report
about : Report a bug in shinyjs.
---

Think you've found a bug in shinyjs? Great, thanks for letting me know!  
Plase try to be as detailed as possible about the issue and include a [minimal reproducible example](https://stackoverflow.com/questions/5963269/how-to-make-a-great-r-reproducible-example) if applicable. 
