---
name  : Ask a Question
about : The issue tracker is not for questions -- please ask questions at https://stackoverflow.com/questions/tagged/shinyjs or https://community.rstudio.com/c/shiny.
---

The issue tracker is not for questions. If you have a question, please feel free to ask it on an online forum where the entire community can help answer your question, such as Twitter or https://stackoverflow.com/questions/tagged/shinyjs or https://community.rstudio.com/c/shiny.
