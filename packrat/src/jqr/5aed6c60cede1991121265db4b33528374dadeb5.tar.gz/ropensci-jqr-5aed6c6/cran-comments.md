## Test environments

* local OS X install, R 4.0.5 patched
* ubuntu 16.04 (on Github Actions), R 4.0.5
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 0 notes

## Reverse dependencies

* I have run R CMD check on the 5 downstream dependencies. No errors were found. Summary at <https://github.com/ropensci/jqr/blob/master/revdep/README.md>.

---

This version updates the libjq version for Windows.

Thanks!
Scott Chamberlain
