#include <libplatform/libplatform.h>
#include <v8.h>
using namespace v8;

int main(){
  V8::Initialize();
}
