# cori_data
Internal package of functions that create, clean, or write data to non-Postgres locations
