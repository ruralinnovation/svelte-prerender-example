#'@seealso \href{http://getbootstrap.com}{Twitter Bootstrap 3}
#'
#'@note
#' Run \code{bsExample("<%=family_name %>")} for an example
#' of \code{<%=item_name %>} functionality.
#' 
#'@family <%=family_name %>
#'@name <%=item_name %>
