## Release Summary

* Updates v2.0.0 to v2.0.1
* reduced R dependency
  

