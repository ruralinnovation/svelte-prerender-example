invisible(geojson::linting_opts(suppress_pkgcheck_warnings = TRUE))
