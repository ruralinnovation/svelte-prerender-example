revdepcheck::revdep_reset()
revdepcheck::revdep_check()
