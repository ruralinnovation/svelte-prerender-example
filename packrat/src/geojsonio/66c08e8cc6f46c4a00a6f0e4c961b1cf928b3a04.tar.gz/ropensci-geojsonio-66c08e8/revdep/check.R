revdepcheck::revdep_reset()
revdepcheck::revdep_check(num_workers = 4)
