# Check times

|   |package        |version | check_time|
|:--|:--------------|:-------|----------:|
|6  |rmapshaper     |0.3.0   |      135.8|
|7  |rmapzen        |0.3.3   |       48.8|
|5  |repijson       |0.1.0   |         47|
|8  |webglobe       |1.0.2   |       38.8|
|1  |antaresViz     |0.11    |       35.7|
|3  |leaflet.extras |0.2     |       20.4|
|4  |mregions       |0.1.6   |       19.2|
|2  |leaflet.esri   |0.2     |       16.8|


