core <- c('cori.data', 'cori.utils', 'cori.db')

core_unloaded <- function() {
  search <- paste0("package:", core)
  core[!search %in% search()]
}


coriverse_attach <- function() {
  to_load <- core_unloaded()
  if (length(to_load) == 0)
    return(invisible())


  suppressPackageStartupMessages(
    lapply(to_load, function(pkg){ do.call(
      "library",
      list(pkg, character.only = TRUE, warn.conflicts = FALSE)
    )})
  )

  invisible()
}


is_attached <- function(x) {
  paste0("package:", x) %in% search()
}

.onAttach <- function(...) {
  needed <- core[!is_attached(core)]
  if (length(needed) == 0)
    return()

  coriverse_attach()


}
