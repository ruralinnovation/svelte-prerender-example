# coriverse
Internal package for the CORI/RISI MDA team

# Development Process

1. Write a function. All functions from external packages should reference the package with :: syntax (e.g. dplyr::filter())
2. Save the function in the R folder of the coriverse repo. The file name should match the function name.
3. Insert a roxygen skeleton (CTRL + SHIFT + ALT + R in RStudio)
4. Update the title, documentation of the parameters, and the return value. Add an `@import` tag for each package the function depends on. If the function uses only one or two functions from an external package, use an `@importFrom` tag for each function.
5. If the packages the function depends on do not appear in the Imports field of the DESCRIPTION file, add the package name(s) there
6. Run `devtools::document()`
7. Run `devtools::check()`
8. If the check passes with no errors, warnings, or notes, push to your branch.
9. Open a pull request and tag Matt R for review.
